<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGADO</title>
</head>
<link rel="stylesheet" type="text/css" href="style.css"> 
      <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@500&display=swap" rel="stylesheet">
      <link rel="icon" type="image/x-icon" href="imagens/logoo.png">
<body>
<nav class="nav">
		<a href="index.html">
			<img src="imagens/logoo.png" class="nav-logo">
		</a>
			<h1>Slime Store</h1>
			<div class="nav-items">
			<button class="menu"><img src="imagens/menu.png"></button>
			<a href="sair.php" class="nav-button">SAIR</a>
	   </div>
    </nav>
</body>
</html>